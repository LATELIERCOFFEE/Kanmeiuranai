// @ts-nocheck
import React from 'react';
import ReactDOM from 'react-dom/client';
import KanmeiUranaiApp from './App.js';
ReactDOM.createRoot(document.getElementById('root')).render(React.createElement(React.StrictMode, null, React.createElement(KanmeiUranaiApp)));
