# 還命占い ホーム画面アプリ版

これは、iPhoneやAndroidのホーム画面から開けるPWA版です。

## いちばん簡単な使い方

1. このフォルダの中身を、Netlify / Vercel / Cloudflare Pages / GitHub Pages などにアップロードします。
2. iPhoneのSafariで公開URLを開きます。
3. 共有ボタン → 「ホーム画面に追加」 → 「追加」。
4. ホーム画面に「還命占い」アイコンが出ます。

## 注意

- iPhoneでホーム画面アプリ化するには、基本的にHTTPSで公開されたURLが必要です。
- この版はビルド不要です。`index.html` が入口です。
- 初回表示時はReactをCDNから読み込みます。表示後はService Workerでキャッシュされます。
- 完全オフラインの初回起動にしたい場合は、Vite版でビルドしてReactも同梱してください。

## 入っているもの

- `index.html`：アプリ入口
- `assets/`：還命占い本体コード
- `manifest.webmanifest`：ホーム画面アプリ用設定
- `sw.js`：キャッシュ用Service Worker
- `icons/`：ホーム画面アイコン
